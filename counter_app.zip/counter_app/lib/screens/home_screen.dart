import 'package:flutter/material.dart';
import 'counter_screen.dart';
import 'about_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home Screen'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0), // Added padding
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'Welcome to the Multi-Screen App!',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold), // Increased font size and weight
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 20),
              Text(
                'This app allows you to navigate between a counter screen and an about screen.',
                style: TextStyle(fontSize: 16),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 40),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => CounterScreen()),
                  );
                },
                icon: Icon(Icons.add),
                label: Text('Go to Counter Screen'),
              ),
              SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => AboutScreen()),
                  );
                },
                icon: Icon(Icons.info),
                label: Text('About This App'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}