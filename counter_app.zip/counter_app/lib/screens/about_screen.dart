import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('About This App'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'This is a simple multi-screen Flutter app.',
                style: TextStyle(fontSize: 18),
                textAlign: TextAlign.center, // Corrected line
              ),
              SizedBox(height: 20),
              Text(
                'You can navigate to the Counter Screen to increment, decrement, and reset the counter.',
                style: TextStyle(fontSize: 16),
                textAlign: TextAlign.center, // Added textAlign property
              ),
              SizedBox(height: 20),
              Text(
                'Developed using Flutter framework.',
                style: TextStyle(fontSize: 16),
                textAlign: TextAlign.center, // Added another text
              ),
            ],
          ),
        ),
      ),
    );
  }
}